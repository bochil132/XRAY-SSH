#!/bin/bash

clear

domain=$(cat /etc/xray/domain)
tls="$(cat ~/log-install.txt | grep -w "Vmess TLS" | cut -d: -f2|sed 's/ //g')"
nontls="$(cat ~/log-install.txt | grep -w "Vmess None TLS" | cut -d: -f2|sed 's/ //g')"
until [[ $user =~ ^[a-zA-Z0-9_]+$ && ${CLIENT_EXISTS} == '0' ]]; do
echo -e "======================================="
echo -e "        Please Input Username"
echo -e "       Or Exit Tap ( CTRL + C )"
echo -e "======================================="
echo ""

		read -p "Input Username : " user
		CLIENT_EXISTS=$(grep -w $user /etc/xray/config.json | wc -l)

		if [[ ${CLIENT_EXISTS} == '1' ]]; then
			echo ""
			echo -e "Username ${RED}${CLIENT_NAME}${NC} Already On VPS Please Choose Another"
			exit 1
		fi
	done

uuid=$(cat /proc/sys/kernel/random/uuid)

read -p "Input Expired  : " masaaktif
echo ""
hariini=`date -d "0 days" +"%Y-%m-%d"`
exp=`date -d "$masaaktif days" +"%Y-%m-%d"`
sed -i '/#xray-vmess-tls$/a\### '"$user $exp"'\
},{"id": "'""$uuid""'"' /etc/xray/config.json
sed -i '/#xray-vmess-nontls$/a\### '"$user $exp"'\
},{"id": "'""$uuid""'"' /etc/xray/config.json

sleep 1
cat>/etc/xray/vmess-$user-tls.json<<EOF
      {
      "v": "2",
      "ps": "${user}",
      "add": "${domain}",
      "port": "${tls}",
      "id": "${uuid}",
      "aid": "0",
      "net": "ws",
      "path": "/v2ray",
      "type": "none",
      "host": "${domain}",
      "tls": "tls"
}
EOF
cat>/etc/xray/vmess-$user-nontls.json<<EOF
      {
      "v": "2",
      "ps": "${user}",
      "add": "${domain}",
      "port": "${nontls}",
      "id": "${uuid}",
      "aid": "0",
      "net": "ws",
      "path": "/v2ray",
      "type": "none",
      "host": "${domain}",
      "tls": "none"
}
EOF
vmess_base641=$( base64 -w 0 <<< $vmess_json1)
vmess_base642=$( base64 -w 0 <<< $vmess_json2)
xrayv2ray1="vmess://$(base64 -w 0 /etc/xray/vmess-$user-tls.json)"
xrayv2ray2="vmess://$(base64 -w 0 /etc/xray/vmess-$user-nontls.json)"
rm -rf /etc/xray/vmess-$user-tls.json
rm -rf /etc/xray/vmess-$user-nontls.json

cat >/home/vps/public_html/vmess-$user.txt <<-END
====================================================================
                  AUTOSCRIPT INSTALLER XRAY-SSH
====================================================================
            Berikut dibawah ini adalah format OpenClash
====================================================================
_______________________________________________________
              Format Vmess WS (CDN) TLS
_______________________________________________________

- name: Vmess-TLS-$user
  type: vmess
  server: ${domain}
  port: 8443
  uuid: ${uuid}
  alterId: 0
  cipher: auto
  udp: true
  tls: true
  skip-cert-verify: true
  servername: ${domain}
  network: ws
  ws-opts:
    path: /v2ray
    headers:
      Host: ${domain}
_______________________________________________________
              Format Vmess WS (CDN) Non TLS
_______________________________________________________

- name: Vmess-NoneTLS-$user
  type: vmess
  server: ${domain}
  port: 8880
  uuid: ${uuid}
  alterId: 0
  cipher: auto
  udp: true
  tls: false
  skip-cert-verify: false
  servername: ${domain}
  network: ws
  ws-opts:
    path: /v2ray
    headers:
      Host: ${domain}
_______________________________________________________
                Link Vmess Account
_______________________________________________________
Link TLS : ${xrayv2ray1}
_______________________________________________________
Link None TLS : ${xrayv2ray2}
_______________________________________________________
END
systemctl restart xray.service
service cron restart
clear
echo -e ""
echo -e "•━━━━━━━━━━━━━━━━━━━━━━•"
echo -e "    Xray/Vmess Account"
echo -e "•━━━━━━━━━━━━━━━━━━━━━━•"
echo -e "Remarks     : ${user}"
echo -e "Domain      : ${domain}"
echo -e "Port TLS    : ${tls}"
echo -e "Port HTTP   : ${nontls}"
echo -e "User ID     : ${uuid}"
echo -e "Alter ID    : 0"
echo -e "Security    : auto"
echo -e "Network     : ws"
echo -e "Path        : /v2ray"
echo -e "Created     : $hariini"
echo -e "Expired     : $exp"
echo -e "•━━━━━━━━━━━━━━━━━━━━━━•"
echo -e "Link TLS  : ${xrayv2ray1}"
echo -e "•━━━━━━━━━━━━━━━━━━━━━━•"
echo -e "Link HTTP : ${xrayv2ray2}"
echo -e "•━━━━━━━━━━━━━━━━━━━━━━•"
echo -e "Format OpenClash :"
echo -e "${domain}:89/vmess-$user.txt"