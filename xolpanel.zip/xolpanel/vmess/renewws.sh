#!/bin/bash
clear
read -rp "Input Username : " user
read -p "Expired (days): " masaaktif
exp=$(grep -E "^### $user" "/etc/xray/config.json" | cut -d ' ' -f 3 | sort | uniq)
now=$(date +%Y-%m-%d)
d1=$(date -d "$exp" +%s)
d2=$(date -d "$now" +%s)
exp2=$(( (d1 - d2) / 86400 ))
exp3=$(($exp2 + $masaaktif))
exp4=`date -d "$exp3 days" +"%Y-%m-%d"`
sed -i "/### $user/c\### $user $exp4" /etc/xray/config.json
sleep 0.5
systemctl restart xray
clear
echo -e "--------------------------------------------------------------"
echo -e "$user Account Renewed Successfully"
echo -e ""
echo -e "Username   : $user"
echo -e "Days Added : $masaaktif Days"
echo -e "Expired On : $exp4"
echo -e "--------------------------------------------------------------"