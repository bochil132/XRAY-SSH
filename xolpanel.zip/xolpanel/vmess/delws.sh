#!/bin/bash
clear
grep -E "^### " "/etc/xray/config.json" | cut -d ' ' -f 2-3 | column -t | sort | uniq | nl
echo ""
read -rp "Input Username : " user
sleep 0.5
exp=$(grep -wE "^### $user" "/etc/xray/config.json" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^### $user $exp/,/^},{/d" /etc/xray/config.json
systemctl restart xray
echo -e "------------------------------------------------------"
echo -e "Username   : $user"
echo -e "Expired On : $exp"
echo -e "------------------------------------------------------"