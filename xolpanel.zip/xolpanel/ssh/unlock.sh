#!/bin/bash
clear
read -p "Username : " user
sleep 0.1
passwd -u ${user}
systemctl restart ws-tls.service
systemctl restart ws-nontls.service
systemctl restart dropbear.servicenya
systemctl restart stunnel5.service