#!/bin/bash
clear
domain=$(cat /etc/xray/domain)
clear
read -p "Input Username : " Login
read -p "Input Password : " Pass
read -p "Input Expired  : "masaaktif

IP=$(wget -qO- ipinfo.io/ip);
ws="$(cat ~/log-install.txt | grep -w "Websocket TLS" | cut -d: -f2|sed 's/ //g')"
ws2="$(cat ~/log-install.txt | grep -w "Websocket HTTP" | cut -d: -f2|sed 's/ //g')"

ssl="$(cat ~/log-install.txt | grep -w "Stunnel5" | cut -d: -f2)"
sqd="$(cat ~/log-install.txt | grep -w "Squid" | cut -d: -f2)"
ovpn="$(netstat -nlpt | grep -i openvpn | grep -i 0.0.0.0 | awk '{print $4}' | cut -d: -f2)"
ovpn2="$(netstat -nlpu | grep -i openvpn | grep -i 0.0.0.0 | awk '{print $4}' | cut -d: -f2)"
clear
systemctl restart ws-tls
systemctl restart ws-nontls

useradd -e `date -d "$masaaktif days" +"%Y-%m-%d"` -s /bin/false -M $Login
sleep 1
expi="$(chage -l $Login | grep "Account expires" | awk -F": " '{print $2}')"
echo -e "$Pass\n$Pass\n"|passwd $Login &> /dev/null
hariini=`date -d "0 days" +"%Y-%m-%d"`
expi=`date -d "$masaaktif days" +"%Y-%m-%d"`
clear
echo -e ""
echo -e "Account Created Successfully"
echo -e "•━━━━━━━━━━━━━━━━━━━━━━•"
echo -e "°Username : $Login"
echo -e "°Password : $Pass"
echo -e "°Created : $hariini"
echo -e "°Expired : $expi"
echo -e "•━━━━━━━━━━━━━━━━━━━━━━•"
echo -e "City : $cityinfo"
echo -e "Domain : ${domain}"
echo -e "Port Ws None Tls : $ws2"
echo -e "Port Ws Tls : $ws"
echo -e "Port Dropbear : 143, 109"
echo -e "Port SSH UDP: 1-65535"
echo -e "Port Stunnel :$ssl"
echo -e "Port Squid :$sqd"
echo -e "Port OpenVPN WS : 2086"
echo -e "Port OpenVPN SSL : 990"
echo -e "Port UDPGW : 7100 - 7300"
echo -e "•━━━━━━━━━━━━━━━━━━━━━━•"
echo -e "•Link Config OpenVPN•"
echo -e "TCP: http://${domain}:89/tcp.ovpn"
echo -e "UDP: http://${domain}:89/udp.ovpn"
echo -e "SSL: http://${domain}:89/ssl.ovpn"
echo -e "•━━━━━━━━━━━━━━━━━━━━━━•"