#!/bin/bash
if [ -e "/root/log-limit.txt" ]; then
echo -e "${multi1}     List of users who do multi-login     ${NC}";
echo ""
cat /root/log-limit.txt
else
echo " User Multilogin No Detected.!!"
echo " "
echo " or"
echo " "
echo " Autokill Script Not Been Executed."
fi
