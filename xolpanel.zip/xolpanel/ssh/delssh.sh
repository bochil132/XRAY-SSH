#!/bin/bash
clear
read -p "Input Username To Delete : " user
sleep 0.5
userdel $user