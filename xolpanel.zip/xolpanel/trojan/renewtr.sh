#!/bin/bash
clear
read -p "Input Username : " client
read -p "Expired (Hari) : " masaaktif
user=$(grep -E "^### $client" "/etc/trojan-go/akun.conf" | cut -d ' ' -f 2)
exp=$(grep -E "^### $client" "/etc/trojan-go/akun.conf" | cut -d ' ' -f 3)
now=$(date +%Y-%m-%d)
d1=$(date -d "$exp" +%s)
d2=$(date -d "$now" +%s)
exp2=$(( (d1 - d2) / 86400 ))
exp3=$(($exp2 + $masaaktif))
exp4=`date -d "$exp3 days" +"%Y-%m-%d"`
sed -i "s/### $user $exp/### $user $exp4/g" /etc/trojan-go/akun.conf
clear
echo ""
echo "============================"
echo "  TrojanGo Account Renewed  "
echo "============================"
echo "Username : $user"
echo "Expired  : $exp4"
echo "=========================="