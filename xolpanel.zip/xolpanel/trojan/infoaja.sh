#!/bin/bash
sleep 0.1
echo "🍀BIGS THANKS FOR🍀"
echo ""
echo "@after_sweet"
echo "@WaanSuka_Turu"
echo "@yha_bot"
echo "@xolv4"