#!/bin/bash
sleep 0.5
cd
cd /root/xolpanel
unzip *.zip &> /dev/null
cp -r backup/passwd /etc/ &> /dev/null
cp -r backup/group /etc/ &> /dev/null
cp -r backup/shadow /etc/ &> /dev/null
cp -r backup/gshadow /etc/ &> /dev/null
cp -r backup/chap-secrets /etc/ppp/ &> /dev/null
cp -r backup/passwd1 /etc/ipsec.d/passwd &> /dev/null
cp -r backup/xray /etc/ &> /dev/null
cp -r backup/settbackup /etc/ &> /dev/null
cp -r backup/show /etc/ &> /dev/null
cp -r backup/trojan-go /etc/ &> /dev/null
cp -r backup/fsidvpn /var/lib/ &> /dev/null
cp -r backup/.acme.sh /root/ &> /dev/null
cp -r backup/conf.d /etc/nginx/ &> /dev/null
cp -r backup/public_html /home/vps/ &> /dev/null
cp -r backup/crontab /etc/ &> /dev/null
cp -r backup/cron.d /etc/ &> /dev/null
sleep 1
echo "•━━━━━━━━━━━━━━━━━━━━━━━━•"
echo "🌀Data Successfully Restored🌀"
echo "•━━━━━━━━━━━━━━━━━━━━━━━━•"