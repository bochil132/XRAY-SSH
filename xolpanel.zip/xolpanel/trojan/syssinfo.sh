#!/bin/bash
source /etc/os-release
totaldisk=$(df -h / | awk '{print $2}' | tail -n1 | sed 's/G//g' | sed 's/ //g')
usedisk=$(df -h / | awk '{print $3}' | tail -n1 | sed 's/G//g' | sed 's/ //g')
useram=$( free -m | awk 'NR==2 {print $3}' )
totalram=$( free -m | awk 'NR==2 {print $2}' )
cpumodel=$( awk -F: '/model name/ {name=$2} END {print name}' /proc/cpuinfo )
uptimesvr="$(uptime -p | cut -d " " -f 2-10)"
corenumber=$( awk -F: '/model name/ {core++} END {print core}' /proc/cpuinfo )
myip=$(curl -s ipinfo.io/ip )
sleep 0.2
echo "🌀OS Name  : $NAME"
echo "🌀OS Versi : $VERSION"
echo "🌀IP       : $myip"
echo "🌀Core     : $corenumber"
echo "🌀Uptime   : $uptimesvr"
echo "🌀Model    :$cpumodel"
echo "🌀Ram      : $totalram Mb / Used $useram Mb"
echo "🌀Storage  : $totaldisk GB / Used $usedisk GB"