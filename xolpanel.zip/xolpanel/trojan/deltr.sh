#!/bin/bash
clear
read -p "Input Username : " user
sleep 0.5
client=$(grep -wE "### $user" "/etc/trojan-go/akun.conf" | cut -d ' ' -f 2 | sort | uniq)
exp=$(grep -wE "### $user" "/etc/trojan-go/akun.conf" | cut -d ' ' -f 3 | sort | uniq)
sed -i "/^### $client $exp/d" /etc/trojan-go/akun.conf
sed -i '/^,"'"$client"'"$/d' /etc/trojan-go/config.json