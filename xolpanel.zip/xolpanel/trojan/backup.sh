#!/bin/bash
# // font
red() { echo -e "\\033[32;1m${*}\\033[0m"; }
IP=$(curl -s ipv4.icanhazip.com)
HOST="$(cat /etc/xray/domain)"
DATEVPS=$(date +"%d-%B-%Y")
ISPVPS=$(cat /etc/xray/isp)
TIME=10
CITY=$(cat /etc/xray/city)
GREEN="\e[92;1m"
BLUE="\033[36m"
RED='\033[0;31m'
NC='\033[0m'
#bottoket
source /root/xolpanel/var.txt
URL=https://api.telegram.org/bot$BOT_TOKEN/sendDocument
HOST="$(cat /etc/xray/domain)"
function BACKUPVPS() {
cd
    mkdir -p /root/backup
    cp -r /etc/settbackup /root/backup/settbackup/ &> /dev/null
cp -r /root/.acme.sh /root/backup/ &> /dev/null
cp -r /etc/xray /root/backup/xray/ &> /dev/null
cp -r /etc/trojan-go /root/backup/trojan-go/ &> /dev/null
cp -r /etc/passwd /root/backup/ &> /dev/null
cp -r /etc/group /root/backup/ &> /dev/null
cp -r /etc/shadow /root/backup/ &> /dev/null
cp -r /etc/gshadow /root/backup/ &> /dev/null
cp -r /etc/ppp/chap-secrets /root/backup/chap-secrets &> /dev/null
cp -r /var/lib/fsidvpn/ /root/backup/fsidvpn &> /dev/null
cp -r /etc/nginx/conf.d /root/backup/conf.d/ &> /dev/null
cp -r /home/vps/public_html /root/backup/public_html &> /dev/null
cp -r /etc/cron.d /root/backup/cron.d &> /dev/null
cp -r /etc/crontab /root/backup/crontab &> /dev/null
    zip -r ${DATEVPS}.zip backup >/dev/null 2>&1
cd /root
curl -F chat_id="$ADMIN" -F document=@"${DATEVPS}.zip" -F caption="$HOST " $URL >/dev/null 2>&1

rm -f ${DATEVPS}.zip
rm -rf backup
}
cd /root
BACKUPVPS
