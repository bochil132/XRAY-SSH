#!/bin/bash
wstls=$(systemctl status ws-tls | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
wsdrop=$(systemctl status ws-nontls | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
myxray=$(systemctl status xray | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
udpsts=$(systemctl status udp-custom | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
trojan_server=$(systemctl status trojan-go | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
dropbr=$(systemctl status dropbear | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
sqd=$(systemctl status squid | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
cron=$(systemctl status cron | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
st5=$(systemctl status stunnel5 | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
udp=$(systemctl status rc-local | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
f2b=$(systemctl status fail2ban | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
sslhh=$(systemctl status sslh | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
shd=$(systemctl status sshd | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
wsovpn=$(systemctl status ws-ovpn | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
shh=$(systemctl status ssh | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
vnst=$(systemctl status vnstat | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)
nginxsts=$(systemctl status nginx | grep Active | awk '{print $3}' | cut -d "(" -f2 | cut -d ")" -f1)

##
if [[ ${wstls} == "running" ]]; then
   ini_wstls="✅ ON"
else
   ini_wstls="❌ OFF"
fi

if [[ ${wsdrop} == "running" ]]; then
   ini_wsdrop="✅ ON"
else
   ini_wsdrop="❌ OFF"
fi

if [[ ${myxray} == "running" ]]; then
   ini_xray="✅ ON"
else
   ini_xray="❌ OFF"
fi

if [[ ${udpsts} == "running" ]]; then
   ini_udpcustom="✅ ON"
else
   ini_udpcustom="❌ OFF"
fi

if [[ ${trojan_server} == "running" ]]; then
   ini_trojan="✅ ON"
else
   ini_trojan="❌ OFF"
fi

if [[ ${dropbr} == "running" ]]; then
   ini_dropbear="✅ ON"
else
   ini_dropbear="❌ OFF"
fi

if [[ ${sqd} == "running" ]]; then
   ini_squid="✅ ON"
else
   ini_squid="❌ OFF"
fi

if [[ ${cron} == "running" ]]; then
   ini_cron="✅ ON"
else
   ini_cron="❌ OFF"
fi

if [[ ${st5} == "running" ]]; then
   ini_stunnel5="✅ ON"
else
   ini_stunnel5="❌ OFF"
fi

if [[ ${udp} == "running" ]]; then
   ini_udp="✅ ON"
else
   ini_udp="❌ OFF"
fi

if [[ ${f2b} == "running" ]]; then
   ini_fail2ban="✅ ON"
else
   ini_fail2ban="❌ OFF"
fi

if [[ ${sslhh} == "running" ]]; then
   ini_sslh="✅ ON"
else
   ini_sslh="❌ OFF"
fi

if [[ ${shd} == "running" ]]; then
   ini_sshd="✅ ON"
else
   ini_sshd="❌ OFF"
fi

if [[ ${wsovpn} == "running" ]]; then
   ini_wsovpn="✅ ON"
else
   ini_wsovpn="❌ OFF"
fi

if [[ ${shh} == "running" ]]; then
   ini_ssh="✅ ON"
else
   ini_ssh="❌ OFF"
fi

if [[ ${vnst} == "running" ]]; then
   ini_vnstat="✅ ON"
else
   ini_vnstat="❌ OFF"
fi

if [[ ${nginxsts} == "running" ]]; then
   ini_nginx="✅ ON"
else
   ini_nginx="❌ OFF"
fi
#========
echo -e "SSH WS TLS     : $ini_wstls"
echo -e "SSH WS NON TLS : $ini_wsdrop"
echo -e "XRAY VMESS     : $ini_xray"
echo -e "XRAY VLESS     : $ini_xray"
echo -e "UDP CUSTOM     : $ini_udpcustom"
echo -e "TROJAN GO      : $ini_trojan"
echo -e "DROPBEAR       : $ini_dropbear"
echo -e "SQUID PROXY    : $ini_squid"
echo -e "CRONTAB        : $ini_cron"
echo -e "STUNNEL 5      : $ini_stunnel5"
echo -e "BADVPN UDPGW   : $ini_udp"
echo -e "FAIL2BAN       : $ini_fail2ban"
echo -e "SSLH           : $ini_sslh"
echo -e "NGINX          : $ini_nginx
echo -e "SSHD           : $ini_sshd"
echo -e "OVPN WS        : $ini_wsovpn"
echo -e "SSH/TUN        : $ini_ssh"
echo -e "VNSTAT         : $ini_vnstat"