#!/bin/bash
clear
uuid=$(cat /etc/trojan-go/uuid.txt)
if [[ "$IP" = "" ]]; then
domain=$(cat /etc/xray/domain)
else
domain=$IP
fi
trgo="$(cat ~/log-install.txt | grep -w "Trojan-Go" | cut -d: -f2|sed 's/ //g')"
		read -p "$( echo -e "${rd}=>${NC} ${C}Input Password :${NC} ")" user
read -p "$( echo -e "${rd}=>${NC} ${C}Input Expired :${NC} ")" masaaktif
sed -i '/"'""$uuid""'"$/a\,"'""$user""'"' /etc/trojan-go/config.json
echo ""
turu=$(date -d "$masaaktif days" +"%Y-%m-%d")
hariini=$(date -d "0 days" +"%Y-%m-%d")
link="trojan://${user}@${domain}:${trgo}/?sni=${domain}&type=ws&host=${domain}&path=/directpath&encryption=none#$user"
cat >/home/vps/public_html/trojanGO-$user.txt <<-END
====================================================================
                  AUTOSCRIPT INSTALLER XRAY-SSH
====================================================================
            Berikut dibawah ini adalah format OpenClash
====================================================================

- name: TrojanGO-TLS-$user
  server: ${domain}
  port: 2087
  type: trojan
  password: ${user}
  skip-cert-verify: true
  sni: ${domain}
  network: ws
  ws-opts:
    path: /directpath
    headers:
      Host: ${domain}
  udp: true

_______________________________________________________
                Link TrojanGo Account
_______________________________________________________
Link TrojanGO : ${link}
_______________________________________________________
END
echo "### ${user} ${turu}" >>/etc/trojan-go/akun.conf
systemctl restart trojan-go.service
echo -e ""
echo -e "•━━━━━━━━━━━━━━━━━━━━━━•"
echo -e "  Trojan-GO Account"
echo -e "•━━━━━━━━━━━━━━━━━━━━━━•"
echo -e "Remarks    : ${user}"
echo -e "Domain     : ${domain}"
echo -e "Port       : ${trgo}"
echo -e "Password   : ${user}"
echo -e "Encryption : none"
echo -e "Path       : /directpath"
echo -e "Created    : $hariini"
echo -e "Expired    : $turu"
echo -e "•━━━━━━━━━━━━━━━━━━━━━━•"
echo -e "Link Trojan-Go : ${link}"
echo -e "•━━━━━━━━━━━━━━━━━━━━━━•"
echo -e "Format OpenClash :"
echo -e "${domain}:89/trojanGO-$user.txt"