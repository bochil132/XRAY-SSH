#!/bin/bash
accounts_trojan=$(grep -E "^### " "/etc/trojan-go/akun.conf" | cut -d ' ' -f 2-3 | column -t | sort | uniq | wc -l)
accounts_ssh="$(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd | wc -l)"
accounts_vmess=$(grep -E "^### " "/etc/xray/config.json" | cut -d ' ' -f 2-3 | column -t | sort | uniq | wc -l)
accounts_vless=$(grep -E "^#### " "/etc/xray/config.json" | cut -d ' ' -f 2-3 | column -t | sort | uniq | wc -l)
##
echo -e "📝VMESS ACCOUNTS  : $accounts_vmess"
echo -e "📝VMESS ACCOUNTS  : $accounts_vless"
echo -e "📝TROJAN ACCOUNTS : $accounts_trojan"
echo -e "📝SSH ACCOUNTS    : $accounts_ssh"