from xolpanel import *

@bot.on(events.NewMessage(pattern="/start"))
async def start(event):
	await event.reply("Hi, This bot_panel by @XolPanel, type /menu to show list button")
