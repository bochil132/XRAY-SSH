from xolpanel import *
import socket

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline(" Menu SSH ","ssh"),
Button.inline(" Menu Vmess ","vmess")],
[Button.inline(" Menu Trojan ","trojan"),
Button.inline(" Menu Vless ","vless")],
[Button.inline(" Features ","setting")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("**⚠️Permission Not Allowed.!!**", alert=True)
		except:
			await event.reply("**⚠️Permission Not Allowed.!!**")
	elif val == "true":
		msg = f"""
×+━━━━━━━━━━━━━━━━━━━━━━+×
         **<<<• BOT MAIN MENU •>>>**
×+━━━━━━━━━━━━━━━━━━━━━━+×
**~DOMAIN     :** __{DOMAIN}__
**~BOT NAME :** __Panel Server__
**~SERVICE     :** __Running__
**~VERSION    :** __New_2.0.1__
×+━━━━━━━━━━━━━━━━━━━━━━+×
**Regards From @WaanSuka_Turu**
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
	else:
		await event.respond(f"** You Dont Have Access**")


