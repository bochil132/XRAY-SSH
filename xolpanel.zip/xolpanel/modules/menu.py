from xolpanel import *
import socket

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline(" 𝚂𝚂𝙷 𝙼𝙴𝙽𝚄 ","ssh"),
Button.inline(" 𝚅𝙼𝙴𝚂𝚂 𝙼𝙴𝙽𝚄 ","vmess")],
[Button.inline(" 𝚃𝚁𝙾𝙹𝙰𝙽 𝙼𝙴𝙽𝚄 ","trojan"),
Button.inline(" 𝚂𝙴𝚃𝚃𝙸𝙽𝙶𝚂 ","setting")],
[Button.inline(" 𝙰𝙲𝙲𝙾𝚄𝙽𝚃𝚂 ","accounts")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		msg = f"""
**•━━━━━━━━━━━━━━━━━•**
•==`🔰MENU BOT PANEL🔰`==•
**•━━━━━━━━━━━━━━━━━•**
🌀𝐁𝐨𝐭 𝐏𝐚𝐧𝐞𝐥 𝐈𝐬 : ✅ ON
🌀𝐁𝐨𝐭 𝐍𝐚𝐦𝐞 : Bot Panel
🌀𝐁𝐨𝐭 𝐕𝐞𝐫𝐬𝐢𝐨𝐧 : 1.3
🌀𝐃𝐨𝐦𝐚𝐢𝐧 : {DOMAIN}
**•━━━━━━━━━━━━━━━━━•**
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
	else:
		await event.respond(f"** You Dont Have Access**")


