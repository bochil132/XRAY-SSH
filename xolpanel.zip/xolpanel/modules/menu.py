from xolpanel import *

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline("✅Masuk Panel✅","ssh"),
Button.url("💰Donasi💰","https://saweria.co/WnDevz")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Permission Denied.!!", alert=True)
		except:
			await event.reply("Permission Denied.!!")
	elif val == "true":
		msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨ 👨‍💻Admin Panel Menu ⟩**
**━━━━━━━━━━━━━━━━**
**» 🌟Mod @WaanSuka_Turu**
**» 🎭Bot @XolPanel**
**» 🤖Bot Version:** `v2.5`
**» 🤖Running Since:** `{uptime}`
**━━━━━━━━━━━━━━━━**
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
