from xolpanel import *

@bot.on(events.CallbackQuery(data=b'delete-ssh'))
async def delete_ssh(event):
	async def delete_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond("**Username To Be Deleted:**")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
			cmd = f'printf "%s\n" "{user}" | delssh'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**User** `{user}` **Not Found**")
		else:
			await event.respond(f"**Successfully Deleted** (`{user}`)")
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'create-ssh'))
async def create_ssh(event):
	async def create_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		async with bot.conversation(chat) as pw:
			await event.respond("**Password:**")
			pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			pw = (await pw).raw_text
		async with bot.conversation(chat) as exp:
			await event.respond("**Choose Expiry Day**",buttons=[
[Button.inline(" 3 Day ","3"),
Button.inline(" 7 Day ","7")],
[Button.inline(" 30 Day ","30"),
Button.inline(" 60 Day ","60")]])
			exp = exp.wait_event(events.CallbackQuery)
			exp = (await exp).data.decode("ascii")
		await event.edit("`Wait.. Setting up an Account`")
		cmd = f'printf "%s\n" "{user}" "{pw}" "{exp}" | addssh'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**User Already Exist**")
		else:
			today = DT.date.today()
			later = today + DT.timedelta(days=int(exp))
			msg = f"""
Accounts Created Successfully
•━━━━━━━━━━━━━━━━━━━━━•
Username:  {user.strip()}
Password: {pw.strip()}
Expired On: {later}
•━━━━━━━━━━━━━━━━━━━━━•
Domain: {DOMAIN}
Port Ws None Tls: 80
Port Ws Tls: 443
Port Dropbear: 143, 109
Port Ssh Udp: 1-65535
Port OpenSSH: 22
Port Stunnel: 443, 445, 777
Port Squid: 3128, 8080
Port OpenVPN WS: 2086
Port OpenVPN SSL: 990
Port OpenVPN UDP: 2200
Port OpenVPN TCP: 1194
Port Udpgw: 7100 - 7300
•━━━━━━━━━━━━━━━━━━━━━•
Config OpenVPN :
http://{DOMAIN}:89/tcp.ovpn
http://{DOMAIN}:89/udp.ovpn
http://{DOMAIN}:89/ssl.ovpn
•━━━━━━━━━━━━━━━━━━━━━•
Payload Ws :
GET / HTTP/1.1 [crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]
•━━━━━━━━━━━━━━━━━━━━━•


"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'show-ssh'))
async def show_ssh(event):
	async def show_ssh_(event):
		cmd = 'listssh'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
```
{z}
```
**Show All SSH User**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await show_ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)



@bot.on(events.CallbackQuery(data=b'trial-ssh'))
async def trial_ssh(event):
	async def trial_ssh_(event):
		user = "trialX"+str(random.randint(100,1000))
		pw = "1"
		exp = "1"
		cmd = f'useradd -e `date -d "{exp} days" +"%Y-%m-%d"` -s /bin/false -M {user} && echo "{pw}\n{pw}" | passwd {user} | echo "killtrial ssh {user}" | at now +60 minutes &> /dev/null'
		try:
			subprocess.check_output(cmd,shell=True)
		except:
			await event.respond("**User Already Exist**")
		else:
			#today = DT.date.today()
			#later = today + DT.timedelta(days=int(exp))
			msg = f"""
Accounts Created Successfully
•━━━━━━━━━━━━━━━━━━━━━•
Username:  {user.strip()}
Password: {pw.strip()}
Expired On: 1 Days
•━━━━━━━━━━━━━━━━━━━━━•
Domain: {DOMAIN}
Port Ws None Tls: 80
Port Ws Tls: 443
Port Dropbear: 143, 109
Port Ssh Udp: 1-65535
Port OpenSSH: 22
Port Stunnel: 443, 445, 777
Port Squid: 3128, 8080
Port OpenVPN WS: 2086
Port OpenVPN SSL: 990
Port OpenVPN UDP: 2200
Port OpenVPN TCP: 1194
Port Udpgw: 7100 - 7300
•━━━━━━━━━━━━━━━━━━━━━•
Config OpenVPN :
http://{DOMAIN}:89/tcp.ovpn
http://{DOMAIN}:89/udp.ovpn
http://{DOMAIN}:89/ssl.ovpn
•━━━━━━━━━━━━━━━━━━━━━•
Payload Ws :
GET / HTTP/1.1 [crlf]Host: {DOMAIN}[crlf]Upgrade: websocket[crlf][crlf]
•━━━━━━━━━━━━━━━━━━━━━•
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trial_ssh_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)
		
@bot.on(events.CallbackQuery(data=b'login-ssh'))
async def login_ssh(event):
	async def login_ssh_(event):
		cmd = 'cekssh'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

{z}
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await login_ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)


@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
	async def ssh_(event):
		inline = [
[Button.inline(" 𝑻𝒓𝒊𝒂𝒍 𝑺𝑺𝑯 ","trial-ssh"),
Button.inline(" 𝑪𝒓𝒆𝒂𝒕𝒆 𝑺𝑺𝑯 ","create-ssh")],
[Button.inline(" 𝑹𝒆𝒎𝒐𝒗𝒆 𝑺𝑺𝑯 ","delete-ssh"),
Button.inline(" 𝑪𝒉𝒆𝒄𝒌 𝑼𝒔𝒆𝒓 𝑶𝒏𝒍𝒊𝒏𝒆 ","login-ssh")],
[Button.inline(" 𝑺𝒉𝒐𝒘 𝑳𝒊𝒔𝒕 𝑼𝒔𝒆𝒓 ","show-ssh")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
**•━━━━━━━━━━━━━━━━━•**
`MENU FOR SSH & OPENVPN`
**•━━━━━━━━━━━━━━━━━•**
**» 🌀Protocol:** __SSH OVPN__
**» 🌀Hostname:** __{DOMAIN}__
**» 🌀ISP:** __{z["isp"]}__
**» 🌀Country:** __{z["country"]}__
**•━━━━━━━━━━━━━━━━━•**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)
