from xolpanel import *

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def menu(event):
	inline = [
[Button.inline("✅GO TO MENU✅","menu")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("⚠️Permission Not Allowed.!!", alert=True)
		except:
			await event.reply("⚠️Permission Not Allowed.!!")
	elif val == "true":
		msg = f"""
|￣￣￣￣￣￣￣|  
|   WELCOME  |
|＿＿＿＿＿_＿_|
(\__/) || 
(•ㅅ•) || 
/ 　 づ
**•=====================•**
**WELCOME TO BOT PANEL**
**BOT PANEL IS RUNNING**
**•=====================•**
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)
	else:
		await event.respond(f"** You Dont Have Access**")
