from xolpanel import *

@bot.on(events.CallbackQuery(data=b'reboot'))
async def rebooot(event):
	async def rebooot_(event):
		cmd = f'reboot'
		subprocess.check_output(cmd, shell=True)
		await event.edit(f"""
**» REBOOT SERVER**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await rebooot_(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)


@bot.on(events.CallbackQuery(data=b'resx'))
async def resx(event):
	async def resx_(event):
		cmd = f'systemctl restart xray | systemctl restart ws-tls | systemctl restart ws-nontls | systemctl restart sslh | systemctl restart stunnel5 | systemctl restart dropbear | systemctl restart nginx | systemctl restart rc-local | systemctl restart cron'
		subprocess.check_output(cmd, shell=True)
		await event.edit(f"""
**» Successfully Restaring Service**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await resx_(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)
		
@bot.on(events.CallbackQuery(data=b'speedtest'))
async def speedtest(event):
	async def speedtest_(event):
		cmd = 'speedtest-cli --share'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		time.sleep(0)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 4%\n█▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 8%\n██▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 20%\n█████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 36%\n█████████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 52%\n█████████████▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 84%\n█████████████████████▒▒▒▒ `")
		time.sleep(0)
		await event.edit("`Processing... 100%\n█████████████████████████ `")
		await event.respond(f"""
**
{z}
**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await speedtest_(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)

@bot.on(events.CallbackQuery(data=b'myservice'))
async def show_ssh(event):
	async def show_ssh_(event):
		cmd = 'infoservice'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
```
{z}
```
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await show_ssh_(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)

@bot.on(events.CallbackQuery(data=b'backup'))
async def backup(event):
	async def backup_(event):
		cmd = f'printf "%s\n" | backupbot'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**Not Exist**")
		else:
			msg = f"""
**
Successfully...
**
"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await backup_(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)

@bot.on(events.CallbackQuery(data=b'showinfo'))
async def show_ssh(event):
	async def show_ssh_(event):
		cmd = 'systeminfo'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
```
{z}
```
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await show_ssh_(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)

@bot.on(events.CallbackQuery(data=b'mybotinfo'))
async def show_ssh(event):
	async def show_ssh_(event):
		cmd = 'infobot'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
{z}
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await show_ssh_(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)

@bot.on(events.CallbackQuery(data=b'rest'))
async def upload(event):
	async def upload_(event):
		me = await bot.get_me()
		async with bot.conversation(event.chat_id) as con:
			await event.reply("**Upload Your File:**")
			file = con.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			file = await file
			file = file.message.media
			file = await event.client.download_media(file,"xolpanel/")
			path = Path(file)
			sex = f"restorebot"
			ox = subprocess.check_output(sex, shell=True).decode("utf-8")
			msg = f"""
{ox}
"""
		await event.respond("Waiting...".format(os.path.basename(file)))
		await event.respond(msg,buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await upload_(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)

@bot.on(events.NewMessage(pattern="(?:.restore|/restore)"))
async def rest(event):
	db = get_db()
	async def rest_(event):
		if event.is_reply:
			try:
				restore = await event.client.download_media(
					await event.get_reply_message(),
					"xolpanel/",
				)
				if "(" not in restore:
					path1 = Path(restore)
					await event.respond(
						"Uploaded To Server `{}`".format(
							os.path.basename(restore)
						)
					)
					owe = subprocess.check_output(restorebot, shell=True)
					await event.respond(f"""{owe}""", 
buttons=[[Button.inline("‹ Main Menu ›","menu")]])
				else:
					os.remove(restore)
					await event.respond("Restore Data Failed")
			except Exception as e:
				await event.respond(str(e))
				os.remove(restore)
		await asyncio.sleep(DELETE_TIMEOUT)
		await event.delete()
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await rest(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)

@bot.on(events.CallbackQuery(data=b'backer'))
async def backers(event):
	async def backers_(event):
		inline = [
[Button.inline(" BACKUP","backup"),
Button.inline(" RESTORE","rest")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
**•━━━━━━━━━━━━━━━•**
**🌀BACKUP & RESTORE🌀**
**•━━━━━━━━━━━━━━━•**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await backers_(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)

@bot.on(events.CallbackQuery(data=b'bandwidth-monitoring'))
async def show_ssh(event):
	async def show_ssh_(event):
		cmd = 'bandwidth-usage'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
```
{z}
```
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await show_ssh_(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)

@bot.on(events.CallbackQuery(data=b'manualres'))
async def delete_ssh(event):
	async def delete_ssh_(event):
		async with bot.conversation(chat) as user:
			await event.respond("**Your Service Name:**")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
			cmd = f'printf "%s\n" "{user}" | restartmanual'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond(f"**Service** `{user}` **Not Found**")
		else:
			await event.respond(f"**Successfully Restart** (`{user}`)")
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await delete_ssh_(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)

@bot.on(events.CallbackQuery(data=b'setting'))
async def settings(event):
	async def settings_(event):
		inline = [
[Button.inline(" 𝚂𝙿𝙴𝙴𝙳𝚃𝙴𝚂𝚃","speedtest"),
Button.inline(" 𝙱𝙰𝙲𝙺𝚄𝙿 & 𝚁𝙴𝚂𝚃𝙾𝚁𝙴","backer")],
[Button.inline(" 𝚁𝙴𝙱𝙾𝙾𝚃 𝚂𝙴𝚁𝚅𝙴𝚁","reboot"),
Button.inline(" 𝚁𝙴𝚂𝚃𝙰𝚁𝚃 𝚂𝙴𝚁𝚅𝙸𝙲𝙴","resx")],
[Button.inline(" 𝚂𝙴𝚁𝚅𝙸𝙲𝙴 𝙸𝙽𝙵𝙾","myservice"),
Button.inline(" 𝚂𝚈𝚂𝚃𝙴𝙼 𝙸𝙽𝙵𝙾","showinfo")],
[Button.inline(" 𝙱𝙾𝚃 𝙸𝙽𝙵𝙾","mybotinfo"),
Button.inline(" 𝙱𝙰𝙽𝙳𝚆𝙸𝙳𝚃𝙷 𝚄𝚂𝙰𝙶𝙴","bandwidth-monitoring")],
[Button.inline(" 𝚁𝙴𝚂𝚃𝙰𝚁𝚃 𝙼𝙰𝙽𝚄𝙰𝙻","manualres")],
[Button.inline("‹ Main Menu ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		msg = f"""
**•━━━━━━━━━━━━━━━•**
**⟨🌀OTHER SETTINGS🌀⟩**
**•━━━━━━━━━━━━━━━•**
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await settings_(event)
	else:
		await event.answer("**⚠️Permission Not Allowed.!!**",alert=True)
