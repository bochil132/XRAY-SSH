#!/bin/bash

clear
cat /root/log-install.txt
echo ""